﻿namespace $safeprojectname$.Models
{
    public class Todo : EntityBase
    {
        public string NazivZadatka { get; set; }

    }
}
