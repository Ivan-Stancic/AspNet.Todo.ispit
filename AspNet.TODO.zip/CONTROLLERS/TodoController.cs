﻿using $safeprojectname$.Repository.Interfaces;
using $safeprojectname$.Models;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class TodoController : Controller
    {
        private readonly ITodoRepository todoRespository;
        private readonly ILogger<HomeController> logger;

        public TodoController(ILogger<HomeController> logger, ITodoRepository todoRespository)
        {
            this.logger = logger;
            this.todoRespository = todoRespository;
        }
        public IActionResult View()
        {
            return View(todoRespository.Get());
        }
    }
}